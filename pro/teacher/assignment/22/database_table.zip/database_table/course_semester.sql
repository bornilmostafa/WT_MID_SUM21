-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 14, 2021 at 05:46 PM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 8.0.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `aisbschoolportal`
--

-- --------------------------------------------------------

--
-- Table structure for table `course_semester`
--

CREATE TABLE `course_semester` (
  `cs_id` int(5) NOT NULL,
  `courseid` varchar(50) NOT NULL,
  `classdecrip` varchar(50) NOT NULL,
  `section` varchar(50) NOT NULL,
  `schedule` varchar(50) NOT NULL,
  `capacity` varchar(50) NOT NULL,
  `semester` varchar(50) NOT NULL,
  `teacherid` varchar(50) NOT NULL,
  `course_status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `course_semester`
--

INSERT INTO `course_semester` (`cs_id`, `courseid`, `classdecrip`, `section`, `schedule`, `capacity`, `semester`, `teacherid`, `course_status`) VALUES
(13, '19-4002', '1', 'B', 'Sun 08.00AM - 11.00AM', '1', '2021, Spring', '19-2001', 'Completed'),
(14, '19-4100', '10', 'A', 'Sun 02.00PM - 05.00PM', '15', '2021, Spring', '19-2001', 'Completed'),
(15, '19-4001', '1', 'L', 'Sun 02.00PM - 05.00PM', '4', '2021, Spring', '19-2001', 'Completed'),
(16, '19-4003', '5', 'I', 'Tue 02.00PM - 05.00PM', '10', '2021, Spring', '19-2001', 'Completed'),
(17, '19-4003', '5', 'I', 'Tue 11.00AM - 02.00PM', '4', '2021, Spring', '19-2001', 'Completed'),
(18, '19-4003', '4', 'I', 'Mon 11.00AM - 02.00PM', '2', '2021, Spring', '19-2001', 'Completed'),
(19, '19-4002', '1', 'C', 'Mon 11.00AM - 02.00PM', '2', '2021, Spring', '19-2001', 'Completed'),
(20, '19-4002', '3', 'C', 'Sun 02.00PM - 05.00PM', '3', '2021, Fall', '30-2005', 'For Registration'),
(21, '19-4002', '2', 'B', 'Tue 08.00AM - 11.00AM', '3', '2021, Fall', '19-2001', 'For Registration'),
(22, '19-4002', '3', 'D', 'Sun 02.00PM - 05.00PM', '4', '2021, Summer', '19-2001', 'Ongoing'),
(24, '50-4555', '5', 'E', 'Mon 11.00AM - 02.00PM', '5', '2021, Summer', '19-2001', 'Ongoing'),
(25, '19-4000', '1', 'B', 'Sun 08.00AM - 11.00AM', '1', '2021, Summer', '19-2001', 'Ongoing'),
(26, '50-4555', '1', 'A', 'Sun 08.00AM - 11.00AM', '1', '2021, Summer', '19-2001', 'Ongoing');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `course_semester`
--
ALTER TABLE `course_semester`
  ADD PRIMARY KEY (`cs_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `course_semester`
--
ALTER TABLE `course_semester`
  MODIFY `cs_id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
