<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>WELCOME,ADMIN</title>
  </head>
  <body>
      <h1 align="Middle"> <b> The Student  INFORMATION AND EDITING PAGE </b> </h1>

      <fieldset>
          <ul>
          <li>  <a href="Student.php">Go TO Student Admisson Page</a></li>
          <li>  <a href="StudentDU.php">Go TO Student Admisson Edit Page</a></li>
          <li><a href="Studentenroll.php">Go TO Student Enroll Page</a> </li>
          <li>  <a href="Studentuneroll.php">Go TO Student Unenroll Page</a></li>
          </ul>





      </fieldset>


  </body>
</html>
