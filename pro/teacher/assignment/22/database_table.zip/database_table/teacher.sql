-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 14, 2021 at 05:48 PM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 8.0.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `aisbschoolportal`
--

-- --------------------------------------------------------

--
-- Table structure for table `teacher`
--

CREATE TABLE `teacher` (
  `id` int(5) NOT NULL,
  `userid` varchar(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `salary` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `gender` varchar(50) NOT NULL,
  `birthday` varchar(50) NOT NULL,
  `nationality` varchar(50) NOT NULL,
  `religion` varchar(50) NOT NULL,
  `bloodgroup` varchar(50) NOT NULL,
  `fathername` varchar(50) NOT NULL,
  `mothername` varchar(50) NOT NULL,
  `joiningdate` varchar(50) NOT NULL,
  `leftdate` varchar(50) NOT NULL,
  `qualification` varchar(50) NOT NULL,
  `presentaddress` varchar(100) NOT NULL,
  `parmanentaddress` varchar(100) NOT NULL,
  `contactnumber` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `teacher`
--

INSERT INTO `teacher` (`id`, `userid`, `name`, `salary`, `email`, `gender`, `birthday`, `nationality`, `religion`, `bloodgroup`, `fathername`, `mothername`, `joiningdate`, `leftdate`, `qualification`, `presentaddress`, `parmanentaddress`, `contactnumber`) VALUES
(2, '19-2001', 'Rubiyet Fardous', '500000', 'rubiyetfardous@gmail.com', 'Male', '1 January 2001', 'bbbhfgghfghf', 'gggggg', 'AB+', 'gggggrgrgr', 'fffff', '1 January 2001', '1 January 2001', 'BSC', 'House #215(Flat #501), Road #8, Block #C, Bashundhara R/A.Dhaka.', 'ttttttttttt', '01862297140'),
(3, '30-2005', 'Rubiyet', '500000', 'rubiyetfardous@gmail.com', 'Male', '1 January 2001', 'bbbhfgghfghf', 'gggggg', 'AB+', 'ggggg', 'ssss', '1 January 2002', '2 January 2001', 'BSC', 'House #215(Flat #501), Road #8, Block #C, Bashundhara R/A.Dhaka.', 'ssss', '01862297140');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `teacher`
--
ALTER TABLE `teacher`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `userid` (`userid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `teacher`
--
ALTER TABLE `teacher`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
