<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Erollment</title>
</head>
<body>
           <h1>Montly and Yearly Enrollment</h1>
           <?php
        require_once "Controllers/studentControl.php";

           ?>




  <form action="" method="post" enctype="multipart/form-data" >
  <tr>
      <td>Admission Date :</td>
      <td>: <input type="text" name="admissiondate"  placeholder="admission date........">  </td>

   
        

        <td colspan="2" align="right"><input type="submit" name="enroll_student"></input>
        </td>


        </form>





                  
      

          

   

          <br>
          <br>
          <br>
          <br>



     <a href="student.php">Go To Student Page</a> 


