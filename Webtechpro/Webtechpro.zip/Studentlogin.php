<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>DASHBOARD</title>
  </head>
  <body>
         <h1> <b>WELCOME  STUDENT </b> </h1>
         <fieldset>
           <a href="Gradereport.php"> <b>Go To Grade REPORT PAGE</b> </a> <br>
           <a href="PasswordC.php"> <b>Password Change </b>  </a>

  <br>
  <br>
  <br>
           <input type="submit" name="submit" value="Log Out">


         </fieldset>


  </body>
</html>
